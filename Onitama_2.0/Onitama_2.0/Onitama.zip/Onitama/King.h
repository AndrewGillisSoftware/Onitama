#pragma once
#include "Piece.h"
#include "Card.h"

class King : public Piece
{
public:
	King();
	~King();

	King(string, double);
};

