#include "stdafx.h"
#include "Game.h"
#include "King.h"
#include "Pawn.h"
#include "Tile.h"
#include <iostream>

Game::Game()
{
}

Game::Game(Player *o, Player *t /*, Card ** aC */,double s)
{
	one = o;
	two = t;
	scale = s;
	winX = 3207 / scale;
	winY = 4000 / scale;
	//allCards = aC;
}


Game::~Game()
{
}

void Game::startGame()
{
	RenderWindow window(VideoMode(winX, winY), "Onitama");

	bool hold = false;
	Vector2i localPosition;

	RectangleShape background;
	RectangleShape aboard;
	Texture T_background;
	Texture T_board;

	//Sets up board for printing
	T_background.loadFromFile("background.jpg");
	T_background.setSmooth(true);
	background.setSize(Vector2f(winX, winY));
	background.setTexture(&T_background);

	T_board.loadFromFile("board.png");
	T_board.setSmooth(true);
	aboard.setSize(Vector2f(1457 / (scale / 1.2), 2706 / (scale / 1.2)));
	aboard.setTexture(&T_board);

	aboard.setPosition(Vector2f(background.getSize().x / 2 - aboard.getSize().x / 2, background.getSize().y / 2 - aboard.getSize().y / 2));

	createBoard();

	refreshPieces();

	//Main control loop
	while (window.isOpen())
	{
		Event event;
		while (window.pollEvent(event))
		{
			switch (event.type)
			{
				case Event::Closed:
					window.close();
					break;
				case Event::MouseButtonPressed:
					localPosition = Mouse::getPosition(window);
					cout << "X:" << localPosition.x << "Y: " << localPosition.y << endl;
					if (hold)
					{
						hold = false;
					}
					else
					{
						hold = true;
					}

			}
		}

		window.clear();
		window.draw(background);
		window.draw(aboard);
		displayBoard(window);
		window.display();
	}

}

void Game::Turn(Player *target)
{
}

bool Game::checkWin(Player *target)
{
	return false;
}

void Game::declareWin(Player *target)
{
}

void Game::move(Vector2i startPos, Vector2i endPos)
{
	
}

void Game::createBoard()
{
	double bSize = winX/11;
	for (int y = 0; y < 5; y++)
	{
		for (int x = 0; x < 5; x++)
		{
			board[x][y].setSize(Vector2f(bSize, bSize));
			board[x][y].setPosition(Vector2f(((bSize+1)*x)+winX/3.7,((bSize+1)*y) + winX / 2.55));
		}
	}
}

void Game::refreshPieces()
{
	Piece **onePieces = one->getPieces();
	Piece **twoPieces = two->getPieces();
	for (int i = 0; i < 5; i++)
	{
		if (onePieces[i]->isAlive())
		{
			board[onePieces[i]->getLocation().x][onePieces[i]->getLocation().y].givePiece(onePieces[i]);
		}
	}
	for (int i = 0; i < 5; i++)
	{
		if (twoPieces[i]->isAlive())
		{
			board[twoPieces[i]->getLocation().x][twoPieces[i]->getLocation().y].givePiece(twoPieces[i]);
		}
	}
}

void Game::displayBoard(RenderWindow &window)
{
	for (int y = 0; y < 5; y++)
	{
		for (int x = 0; x < 5; x++)
		{
			if (board[x][y].isOccupied())
			{
				if (board[x][y].getPiece()->isAlive())
				{
					board[x][y].drawPiece(window);
				}
			}
		}
	}
}

void Game::endGame()
{
}
