#pragma once
#include <string>
#include <iostream>
#include <SFML/Graphics.hpp>
#include "Piece.h"

using namespace std;
using namespace sf;

class Tile : public RectangleShape
{
public:
	Tile();
	~Tile();
	
	bool isOccupied();
	void givePiece(Piece*);
	Piece* getPiece();
	void removePiece();
	void removeOccupied();
	void drawPiece(RenderWindow&);

private:
	Piece*p;
	bool occupied;
};

