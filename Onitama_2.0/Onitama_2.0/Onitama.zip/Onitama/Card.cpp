#include "stdafx.h"
#include "Card.h"


Card::Card()
{
}


Card::~Card()
{
}
