#include "stdafx.h"
#include "Tile.h"


Tile::Tile()
{
	occupied = false;
}

Tile::~Tile()
{
}

bool Tile::isOccupied()
{
	return occupied;
}

//Read access violation a empty pointer is tossed to give piece
//Major issue is tiles keep their occupation when the piece is given ownership to a new tile
void Tile::givePiece(Piece *tP)
{
	p = tP;
	occupied = true;
	double sizeX = p->getTexture()->getSize().x * p->getScale().x;
	double sizeY = p->getTexture()->getSize().y * p->getScale().y;
	p->setPosition(Vector2f(getPosition().x + getSize().x / 2 - sizeX / 2, getPosition().y + getSize().y / 2 - sizeY / 2));
}
Piece * Tile::getPiece()
{
	return p;
}

void Tile::removePiece()
{
	p = nullptr;
	occupied = false;
}

void Tile::removeOccupied()
{
	occupied = false;
}

void Tile::drawPiece(RenderWindow &window)
{
	if (occupied)
	{
		window.draw(*p);
	}
}


