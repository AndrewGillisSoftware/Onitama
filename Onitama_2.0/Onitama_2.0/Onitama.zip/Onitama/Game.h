#pragma once
#include <SFML/Graphics.hpp>
#include "Player.h"
#include "Card.h"
#include "Tile.h"

using namespace std;
using namespace sf;

class Game
{
public:
	Game();
	Game(Player*, Player* /*, Card ***/, double);
	~Game();

	void startGame();
	void endGame();

private:
	Player *one, *two;
	Card ** allCards;
	Card ** inPlay;
	Tile board[5][5];
	Piece allPieces[10];

	void Turn(Player*);
	bool checkWin(Player*);
	void declareWin(Player*);
	void move(Vector2i,Vector2i);

	void createBoard();
	void refreshPieces();
	void displayBoard(RenderWindow&);

	double scale;
	double winX;
	double winY;
};

