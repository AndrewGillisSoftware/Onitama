#include "stdafx.h"
#include "King.h"


King::King()
{
}


King::~King()
{
}

King::King(string t, double scale)
{
	team = t;
	type.loadFromFile(t + "King.png");
	setTexture(type);
	setScale(0.4/scale, 0.4/scale);
	type.setSmooth(true);
}
