#include "stdafx.h"
#include "Piece.h"


Piece::Piece()
{
	alive = true;
}


Piece::~Piece()
{
}

void Piece::move()
{
}

void Piece::setLocation(Vector2i nL)
{
	location = nL;
}

Vector2i Piece::getLocation()
{
	return location;
}

string Piece::getTeam()
{
	return team;
}

void Piece::kill()
{
	alive = false;
}

bool Piece::isAlive()
{
	return alive;
}
