#pragma once
#include "Piece.h"
#include "Card.h"

class Pawn : public Piece
{
public:
	Pawn();
	~Pawn();

	Pawn(string, double);
};

