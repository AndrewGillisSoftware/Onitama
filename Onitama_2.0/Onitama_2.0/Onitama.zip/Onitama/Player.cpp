#include "stdafx.h"
#include "Player.h"


Player::Player()
{
}

Player::Player(string n, string t, double s)
{
	name = n;
	team = t;

		pieces = new Piece*[5];
		pieces[0] = new Pawn(team, s);
		pieces[1] = new Pawn(team, s);
		pieces[3] = new Pawn(team, s);
		pieces[4] = new Pawn(team, s);
		pieces[2] = new King(team, s);

	if ("blue" == team)
	{
		for (int x = 0; x < 5; x++)
		{
			pieces[x]->setLocation(Vector2i(x,0));
		}
	}
	else if ("red" == team)
	{
		for (int x = 0; x < 5; x++)
		{
			pieces[x]->setLocation(Vector2i(x, 4));
		}
	}
	else
		cout << endl << "A Player Identification Error (Player Constructor) has Occured!" << endl;
}


Player::~Player()
{
}

Piece ** Player::getPieces()
{
	return pieces;
}

string Player::getTeam()
{
	return team;
}
