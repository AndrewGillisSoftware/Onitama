#pragma once
#include <iostream>
#include "Piece.h"
#include "Pawn.h"
#include "King.h"
#include <string>
class Player
{
public:
	Player();
	Player(string, string, double);
	~Player();

	Piece ** getPieces();
	string getTeam();

private:
	string name, team;
	Piece ** pieces;
};

