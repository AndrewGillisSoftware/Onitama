#pragma once
class Card
{
public:
	Card();
	~Card();

private:

};

