#include "stdafx.h"
#include "Pawn.h"


Pawn::Pawn()
{
}


Pawn::~Pawn()
{
}

Pawn::Pawn(string t, double scale)
{
	team = t;
	type.loadFromFile(t + "Pawn.png");
	setTexture(type);
	setScale(0.4/scale, 0.4/scale);
	type.setSmooth(true);
}
